package com.hajira.trip

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Intent
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.content.FileProvider
import androidx.webkit.WebViewAssetLoader
import java.io.File

class MainActivity : Activity() {
    private lateinit var web: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): WebResourceResponse? = loader.shouldInterceptRequest(request.url)
        }
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(Bridge(), "Android")

        if (savedInstanceState == null) {
            web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
        } else {
            web.restoreState(savedInstanceState)
        }
    }

    private fun js(code: String) {
        web.post { web.evaluateJavascript(code, null) }
    }

    inner class Bridge {
        // ট্রিপের JSON ফাইল বানিয়ে সরাসরি Gmail-এ (মালিকের ঠিকানাসহ) পাঠানোর মেইল খোলে
        @JavascriptInterface
        fun sendTrips(email: String, subject: String, body: String, fileName: String, json: String) {
            runOnUiThread {
                try {
                    val dir = File(cacheDir, "share")
                    dir.mkdirs()
                    dir.listFiles()?.forEach { it.delete() }
                    val file = File(dir, fileName)
                    file.writeText(json, Charsets.UTF_8)
                    val uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", file)

                    val i = Intent(Intent.ACTION_SEND).apply {
                        type = "application/json"
                        if (email.isNotBlank()) putExtra(Intent.EXTRA_EMAIL, arrayOf(email))
                        putExtra(Intent.EXTRA_SUBJECT, subject)
                        putExtra(Intent.EXTRA_TEXT, body)
                        putExtra(Intent.EXTRA_STREAM, uri)
                        clipData = ClipData.newRawUri("trips", uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    try {
                        i.setPackage("com.google.android.gm")
                        startActivity(i)
                    } catch (e: ActivityNotFoundException) {
                        // Gmail না থাকলে অন্য মেইল অ্যাপ বেছে নেওয়ার তালিকা
                        i.setPackage(null)
                        val c = Intent.createChooser(i, "মেইল অ্যাপ বেছে নিন")
                        c.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        startActivity(c)
                    }
                } catch (e: Exception) {
                    js("hjShareFail()")
                }
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("(window.hjBack ? window.hjBack() : false)") { r ->
            if (r != "true") {
                if (web.canGoBack()) web.goBack() else finish()
            }
        }
    }
}
