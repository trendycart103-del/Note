package com.hajira.tripentry

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import java.io.File

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var voiceTarget = 0

    companion object {
        private const val REQ_VOICE = 5001
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): WebResourceResponse? = loader.shouldInterceptRequest(request.url)
        }
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(Bridge(), "Android")

        if (savedInstanceState == null) {
            web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
        } else {
            web.restoreState(savedInstanceState)
        }
    }

    inner class Bridge {
        // গন্তব্যের জন্য বাংলায় ভয়েস টাইপ (ফোনের Google ভয়েস সার্ভিস ব্যবহার করে)
        @JavascriptInterface
        fun voice(index: Int) {
            runOnUiThread {
                voiceTarget = index
                val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "bn-BD")
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "গন্তব্যের নাম বলুন")
                }
                try {
                    startActivityForResult(i, REQ_VOICE)
                } catch (e: ActivityNotFoundException) {
                    Toast.makeText(this@MainActivity, "ভয়েস টাইপ চালু নেই — কিবোর্ডের 🎤 ব্যবহার করুন", Toast.LENGTH_LONG).show()
                }
            }
        }

        // কোড ক্লিপবোর্ডে কপি করে (এরপর যেখানে খুশি পেস্ট করা যাবে)
        @JavascriptInterface
        fun copy(text: String) {
            runOnUiThread {
                try {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("trips", text))
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "কপি করা যায়নি", Toast.LENGTH_LONG).show()
                }
            }
        }

        // JSON ফাইল সংযুক্ত করে Gmail খোলে; প্রাপকের ঠিকানা আগে থেকে বসানো থাকে (পাঠানোর জন্য শুধু Send চাপতে হবে)
        @JavascriptInterface
        fun shareFile(to: String, subject: String, body: String, name: String, json: String) {
            runOnUiThread {
                try {
                    val dir = File(cacheDir, "shared").apply { mkdirs() }
                    dir.listFiles()?.forEach { it.delete() }
                    val f = File(dir, name)
                    f.writeText(json, Charsets.UTF_8)
                    val uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", f)
                    val mail = Intent(Intent.ACTION_SEND).apply {
                        type = "application/json"
                        putExtra(Intent.EXTRA_EMAIL, arrayOf(to))
                        putExtra(Intent.EXTRA_SUBJECT, subject)
                        putExtra(Intent.EXTRA_TEXT, body)
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    try {
                        startActivity(Intent(mail).setPackage("com.google.android.gm"))
                    } catch (e: ActivityNotFoundException) {
                        startActivity(Intent.createChooser(mail, null))
                    }
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "শেয়ার করা যায়নি", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_VOICE && resultCode == RESULT_OK) {
            val text = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!text.isNullOrBlank()) {
                val code = "hjVoice(" + voiceTarget + "," + JSONObject.quote(text) + ")"
                web.post { web.evaluateJavascript(code, null) }
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("(window.hjBack ? window.hjBack() : false)") { r ->
            if (r != "true") finish()
        }
    }
}
