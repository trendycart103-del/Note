হাজিরা ও ট্রিপ নোটবুক — Android Studio প্রজেক্ট
==============================================

APK বানানোর নিয়ম:
1. কম্পিউটারে Android Studio (নতুন সংস্করণ) ইনস্টল করুন।
2. File > Open থেকে এই আনজিপ করা HajiraNotebook ফোল্ডারটি খুলুন।
3. Gradle Sync শেষ হওয়া পর্যন্ত অপেক্ষা করুন (প্রথমবার ইন্টারনেট লাগবে)।
4. মেনু থেকে Build > Build Bundle(s) / APK(s) > Build APK(s) চাপুন।
5. তৈরি ফাইল: app/build/outputs/apk/debug/app-debug.apk
6. APK ফোনে পাঠিয়ে ইনস্টল করুন (Unknown sources অনুমতি লাগতে পারে)।

অ্যাপের কোড: app/src/main/assets/index.html
নাম বদলাতে: app/src/main/AndroidManifest.xml এর android:label
ডেটা ফোনের ভেতরেই জমা থাকে।
