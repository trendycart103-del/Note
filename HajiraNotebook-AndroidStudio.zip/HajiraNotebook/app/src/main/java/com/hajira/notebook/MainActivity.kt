package com.hajira.notebook

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var pendingExport: String? = null
    private var pageReady = false
    private var pendingShared: String? = null

    companion object {
        private const val REQ_EXPORT = 4101
        private const val REQ_IMPORT = 4102
        private const val MAX_IMPORT_BYTES = 20 * 1024 * 1024
        private const val OWNER_EMAIL = "softcare2016@gmail.com"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): WebResourceResponse? = loader.shouldInterceptRequest(request.url)

            override fun onPageFinished(view: WebView, url: String?) {
                pageReady = true
                deliverShared()
            }
        }
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(Bridge(), "Android")

        if (savedInstanceState == null) {
            web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
        } else {
            web.restoreState(savedInstanceState)
        }
        takeShared(intent)
    }

    // ট্রিপ এন্ট্রি অ্যাপ (বা অন্য কোনো অ্যাপ) থেকে শেয়ার করা টেক্সট ধরে অটো-ইমপোর্ট করে
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        takeShared(intent)
    }

    private fun takeShared(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND && i.type?.startsWith("text/") == true) {
            val t = i.getStringExtra(Intent.EXTRA_TEXT)
            if (!t.isNullOrEmpty() && t.length <= MAX_IMPORT_BYTES) {
                pendingShared = t
                // একই ইনটেন্ট দুইবার প্রসেস না হওয়ার জন্য
                i.action = null
                deliverShared()
            }
        }
    }

    private fun deliverShared() {
        val t = pendingShared ?: return
        if (!pageReady) return
        pendingShared = null
        js("(window.hjImportTrips ? hjImportTrips(" + JSONObject.quote(t) + ") : 0)")
    }

    private fun js(code: String) {
        web.post { web.evaluateJavascript(code, null) }
    }

    inner class Bridge {
        @JavascriptInterface
        fun share(text: String) {
            runOnUiThread {
                val i = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, text)
                }
                startActivity(Intent.createChooser(i, null))
            }
        }

        // শেয়ার: ডিফল্টভাবে Gmail খোলে, প্রাপক softcare2016@gmail.com আগে থেকেই বসানো থাকে
        @JavascriptInterface
        fun shareMail(subject: String, text: String) {
            runOnUiThread {
                val mail = Intent(Intent.ACTION_SENDTO).apply {
                    data = Uri.parse("mailto:")
                    putExtra(Intent.EXTRA_EMAIL, arrayOf(OWNER_EMAIL))
                    putExtra(Intent.EXTRA_SUBJECT, subject)
                    putExtra(Intent.EXTRA_TEXT, text)
                }
                try {
                    startActivity(Intent(mail).setPackage("com.google.android.gm"))
                } catch (e: ActivityNotFoundException) {
                    try {
                        startActivity(Intent.createChooser(mail, null))
                    } catch (e2: ActivityNotFoundException) {
                        Toast.makeText(this@MainActivity, "ইমেইল অ্যাপ পাওয়া যায়নি", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }

        // ব্যাকআপ: ফোনের ফাইল-সেভ স্ক্রিন খুলে JSON ফাইল সেভ করায় (কোনো পারমিশন লাগে না)
        @JavascriptInterface
        fun exportJson(name: String, json: String) {
            runOnUiThread {
                pendingExport = json
                val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                    putExtra(Intent.EXTRA_TITLE, name)
                }
                try {
                    startActivityForResult(i, REQ_EXPORT)
                } catch (e: ActivityNotFoundException) {
                    pendingExport = null
                    Toast.makeText(this@MainActivity, "ফাইল সেভ করার অ্যাপ পাওয়া যায়নি", Toast.LENGTH_LONG).show()
                }
            }
        }

        // রিস্টোর: ফোনের ফাইল-পিকার খুলে JSON ফাইল বেছে নেওয়ায়
        @JavascriptInterface
        fun importJson() {
            runOnUiThread {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                try {
                    startActivityForResult(i, REQ_IMPORT)
                } catch (e: ActivityNotFoundException) {
                    Toast.makeText(this@MainActivity, "ফাইল বাছাই করার অ্যাপ পাওয়া যায়নি", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode == REQ_EXPORT) {
            val text = pendingExport
            pendingExport = null
            if (resultCode == RESULT_OK && uri != null && text != null) {
                val ok = try {
                    contentResolver.openOutputStream(uri, "wt")?.use {
                        it.write(text.toByteArray(Charsets.UTF_8))
                    }
                    true
                } catch (e: Exception) {
                    false
                }
                js("hjBackupDone($ok)")
            }
        } else if (requestCode == REQ_IMPORT) {
            if (resultCode == RESULT_OK && uri != null) {
                val text: String? = try {
                    contentResolver.openInputStream(uri)?.use { s ->
                        val bytes = s.readBytes()
                        if (bytes.size > MAX_IMPORT_BYTES) null else String(bytes, Charsets.UTF_8)
                    }
                } catch (e: Exception) {
                    null
                }
                if (text != null) js("hjRestoreText(" + JSONObject.quote(text) + ")")
                else js("hjRestoreText('')")
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    // ব্যাক চাপলে আগে পপ-আপ/ক্যালকুলেটর বন্ধ হবে, তারপর অ্যাপ
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("(window.hjBack ? window.hjBack() : false)") { r ->
            if (r != "true") {
                if (web.canGoBack()) web.goBack() else finish()
            }
        }
    }
}
