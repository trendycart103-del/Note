# গাড়ীর হিসাব APK
1. এই ফোল্ডারের সব ফাইল GitHub রিপোজিটরিতে আপলোড করুন।
2. Actions ট্যাব > Build APK > Run workflow।
3. শেষ হলে Artifacts থেকে gaarir-hisab-apk ডাউনলোড করুন।
অ্যাপের কোড: www/index.html
