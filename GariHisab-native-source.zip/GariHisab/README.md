# গাড়ীর হিসাব (নেটিভ অ্যান্ড্রয়েড)
Java, কোনো WebView/HTML নেই। GitHub-এ পুশ করলে Actions → "Build APK" চলে; শেষে Artifacts থেকে APK নামান।
- Store.java: ডেটা + হিসাবের নিয়ম  - MainActivity.java: ৪টি পেজ  - CalcBubble.java: ভাসমান রঙিন ক্যালকুলেটর
