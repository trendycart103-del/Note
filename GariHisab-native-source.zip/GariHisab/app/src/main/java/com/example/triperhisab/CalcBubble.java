package com.example.triperhisab;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.*;

/** স্ক্রিনের উপরে ভাসমান ছোট ক্যালকুলেটর বাবল। ক্লিক করলে রঙিন ক্যালকুলেটর খোলে। */
public class CalcBubble extends FrameLayout {
    private final TextView dot, screen;
    private final LinearLayout panel;
    private String expr = "";
    private float offX, offY, startX, startY;
    private boolean moved;

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + .5f); }

    private GradientDrawable grad(int a, int b, int radius, boolean oval) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{a, b});
        if (oval) g.setShape(GradientDrawable.OVAL); else g.setCornerRadius(dp(radius));
        return g;
    }
    private GradientDrawable solid(int c, int r) {
        GradientDrawable g = new GradientDrawable(); g.setColor(c); g.setCornerRadius(dp(r)); return g;
    }

    public CalcBubble(Context c) {
        super(c);
        setElevation(dp(8));
        // ছোট বাবল (৩৬dp)
        dot = new TextView(c);
        dot.setText("🧮"); dot.setTextSize(17); dot.setGravity(Gravity.CENTER);
        dot.setBackground(grad(0xFFFF6A00, 0xFFEE0979, 0, true));
        addView(dot, new LayoutParams(dp(36), dp(36)));

        // খোলা ক্যালকুলেটর (২৫০dp)
        panel = new LinearLayout(c);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(10), dp(10), dp(10), dp(10));
        panel.setBackground(grad(0xFF1E1B4B, 0xFF4338CA, 18, false));
        panel.setVisibility(GONE);
        addView(panel, new LayoutParams(dp(250), LayoutParams.WRAP_CONTENT));

        LinearLayout top = new LinearLayout(c);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(c);
        title.setText("ক্যালকুলেটর"); title.setTextColor(0xFFC7D2FE); title.setTextSize(12);
        top.addView(title, new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1));
        TextView x = new TextView(c);
        x.setText("✕"); x.setTextColor(Color.WHITE); x.setGravity(Gravity.CENTER); x.setBackground(grad(0xFFEF4444, 0xFFEF4444, 0, true));
        x.setOnClickListener(v -> close());
        top.addView(x, new LinearLayout.LayoutParams(dp(26), dp(26)));
        panel.addView(top);

        screen = new TextView(c);
        screen.setText("0"); screen.setTextSize(24); screen.setTextColor(0xFF34D399); screen.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        screen.setSingleLine(true); screen.setBackground(solid(0xFF0F172A, 10)); screen.setPadding(dp(10), dp(6), dp(10), dp(6));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, dp(46));
        sp.topMargin = dp(6);
        panel.addView(screen, sp);

        String[] keys = {"C","(",")","÷","7","8","9","×","4","5","6","−","1","2","3","+","0",".","⌫","="};
        for (int r = 0; r < 5; r++) {
            LinearLayout row = new LinearLayout(c);
            for (int k = 0; k < 4; k++) {
                final String key = keys[r * 4 + k];
                int col = key.equals("=") ? 0xFF10B981 : (key.equals("C") || key.equals("⌫")) ? 0xFFEF4444
                        : "+−×÷()".contains(key) ? 0xFFF59E0B : 0xFF0EA5E9;
                TextView b = new TextView(c);
                b.setText(key); b.setTextSize(18); b.setTextColor(Color.WHITE); b.setGravity(Gravity.CENTER);
                b.setTypeface(null, android.graphics.Typeface.BOLD); b.setBackground(solid(col, 10));
                b.setOnClickListener(v -> press(key));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(44), 1);
                lp.setMargins(dp(3), dp(3), dp(3), dp(3));
                row.addView(b, lp);
            }
            panel.addView(row);
        }

        dot.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    offX = getX() - e.getRawX(); offY = getY() - e.getRawY();
                    startX = e.getRawX(); startY = e.getRawY(); moved = false; return true;
                case MotionEvent.ACTION_MOVE:
                    if (Math.abs(e.getRawX() - startX) + Math.abs(e.getRawY() - startY) > dp(6)) moved = true;
                    if (moved) place(e.getRawX() + offX, e.getRawY() + offY);
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!moved) open();
                    return true;
            }
            return false;
        });
    }

    private void place(float x, float y) {
        View p = (View) getParent();
        if (p == null) return;
        setX(Math.max(0, Math.min(p.getWidth() - getWidth(), x)));
        setY(Math.max(0, Math.min(p.getHeight() - getHeight(), y)));
    }
    void open() { dot.setVisibility(GONE); panel.setVisibility(VISIBLE); post(() -> place(getX(), getY())); }
    void close() { panel.setVisibility(GONE); dot.setVisibility(VISIBLE); }

    private void press(String k) {
        if (k.equals("C")) expr = "";
        else if (k.equals("⌫")) { if (!expr.isEmpty()) expr = expr.substring(0, expr.length() - 1); }
        else if (k.equals("=")) {
            try {
                double r = new P(expr.replace("×", "*").replace("÷", "/").replace("−", "-")).run();
                if (Double.isNaN(r) || Double.isInfinite(r)) throw new RuntimeException();
                expr = plain(r);
            } catch (Exception ex) { expr = ""; screen.setText("ভুল"); return; }
        } else expr += k;
        screen.setText(expr.isEmpty() ? "0" : expr);
    }
    private String plain(double r) {
        r = Math.round(r * 1e8) / 1e8;
        return r == Math.rint(r) && Math.abs(r) < 1e15 ? String.valueOf((long) r) : String.valueOf(r);
    }

    /** ছোট এক্সপ্রেশন পার্সার: + - * / ( ) ও দশমিক */
    private static class P {
        final String s; int p = 0;
        P(String s) { this.s = s.replace(" ", ""); }
        double run() { double v = expr(); if (p != s.length()) throw new RuntimeException(); return v; }
        double expr() {
            double v = term();
            while (p < s.length() && (s.charAt(p) == '+' || s.charAt(p) == '-')) { char c = s.charAt(p++); double t = term(); v = c == '+' ? v + t : v - t; }
            return v;
        }
        double term() {
            double v = factor();
            while (p < s.length() && (s.charAt(p) == '*' || s.charAt(p) == '/')) { char c = s.charAt(p++); double t = factor(); v = c == '*' ? v * t : v / t; }
            return v;
        }
        double factor() {
            if (p >= s.length()) throw new RuntimeException();
            char c = s.charAt(p);
            if (c == '-') { p++; return -factor(); }
            if (c == '(') { p++; double v = expr(); if (p >= s.length() || s.charAt(p) != ')') throw new RuntimeException(); p++; return v; }
            int st = p;
            while (p < s.length() && (Character.isDigit(s.charAt(p)) || s.charAt(p) == '.')) p++;
            return Double.parseDouble(s.substring(st, p));
        }
    }
}
