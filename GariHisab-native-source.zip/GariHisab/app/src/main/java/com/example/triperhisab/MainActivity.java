package com.example.triperhisab;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONObject;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    static final int BRAND = 0xFF1769E0, GREEN = 0xFF138A58, RED = 0xFFC62828, INK = 0xFF182230, MUTED = 0xFF65758B;
    static final double[] PV = {1, 0, 0.5};
    static final String[] PN = {"উপস্থিত", "অনুপস্থিত", "অর্ধেক"};
    static final String[] TABS = {"👷 হাজিরা ও বেতন", "🚚 ট্রিপ পেজ", "📊 সাপ্তাহিক রিপোর্ট", "💾 ব্যাকআপ"};

    LinearLayout[] pages = new LinearLayout[4];
    TextView[] tabs = new TextView[4];
    FrameLayout root;

    static class WRow { Spinner p; EditText w, a; }
    static class TEntry { String date; Spinner m; EditText dest, q, r, l; TextView total; }
    List<WRow> wrows = new ArrayList<>();
    List<TEntry> entries = new ArrayList<>();
    Map<String, TextView> dayHeads = new HashMap<>();
    TextView todayWage, presentCount, advTotal, entryDate, tripCount, tripCost, laborCost, tripGrand;
    TextView wkFare, wkLabor, wkNet, wkComm, repGrand, rtFare, rtLabor, rtNet, rtComm;
    LinearLayout attList, tripWeek, wkRows, tripDetail, repRows, repTripRows;
    String pendingExport;

    // ---------- UI সহায়ক ----------
    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + .5f); }
    GradientDrawable bg(int c, int r) { GradientDrawable g = new GradientDrawable(); g.setColor(c); g.setCornerRadius(dp(r)); return g; }
    TextView tv(String t, int sp, int color, boolean bold) {
        TextView v = new TextView(this); v.setText(t); v.setTextSize(sp); v.setTextColor(color);
        if (bold) v.setTypeface(null, Typeface.BOLD); return v;
    }
    LinearLayout vbox() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    LinearLayout hbox() { LinearLayout l = new LinearLayout(this); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    LinearLayout.LayoutParams mp(int top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.topMargin = dp(top); return p;
    }
    LinearLayout card(LinearLayout page, String title) {
        LinearLayout c = vbox(); c.setBackground(bg(Color.WHITE, 16)); c.setPadding(dp(14), dp(14), dp(14), dp(14));
        if (title != null) { TextView h = tv(title, 18, INK, true); c.addView(h); }
        page.addView(c, mp(12)); return c;
    }
    TextView note(String t) { TextView v = tv(t, 12, MUTED, false); v.setPadding(0, dp(6), 0, dp(6)); return v; }
    Button btn(String t, int bg, int fg, View.OnClickListener c) {
        Button b = new Button(this); b.setText(t); b.setTextColor(fg); b.setAllCaps(false); b.setTypeface(null, Typeface.BOLD);
        b.setBackground(bg(bg, 10)); b.setOnClickListener(c); b.setMinHeight(0); b.setMinimumHeight(dp(42)); return b;
    }
    EditText et(String hint, boolean num, String val) {
        EditText e = new EditText(this); e.setHint(hint); e.setTextSize(15); e.setSingleLine(true);
        if (num) e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        if (val != null) e.setText(val); return e;
    }
    LinearLayout labeled(String label, View v) {
        LinearLayout l = vbox(); l.addView(tv(label, 12, MUTED, true)); l.addView(v); l.setPadding(0, dp(6), 0, 0); return l;
    }
    TextView stat(LinearLayout row, String label) {
        LinearLayout b = vbox(); b.setBackground(bg(0xFFEDF4FF, 13)); b.setPadding(dp(10), dp(10), dp(10), dp(10));
        b.addView(tv(label, 11, MUTED, false)); TextView v = tv("৳০", 17, INK, true); b.addView(v);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1); p.setMargins(dp(3), dp(3), dp(3), dp(3));
        row.addView(b, p); return v;
    }
    LinearLayout statRow(LinearLayout parent) { LinearLayout r = new LinearLayout(this); parent.addView(r, mp(0)); return r; }
    LinearLayout cols(boolean head, String... c) {
        LinearLayout r = new LinearLayout(this); r.setPadding(0, dp(7), 0, dp(7));
        if (head) r.setBackgroundColor(0xFFF5F8FD);
        for (String s : c) { TextView t = tv(s, 12, head ? 0xFF40516A : INK, head); r.addView(t, new LinearLayout.LayoutParams(0, -2, 1)); }
        return r;
    }
    LinearLayout band(LinearLayout parent, String label, TextView[] out) {
        LinearLayout b = hbox(); b.setBackground(bg(0xFFE6F4EC, 12)); b.setPadding(dp(12), dp(12), dp(12), dp(12));
        b.addView(tv(label, 14, INK, true), new LinearLayout.LayoutParams(0, -2, 1));
        out[0] = tv("৳০", 18, GREEN, true); b.addView(out[0]); parent.addView(b, mp(10)); return b;
    }
    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
    void confirm(String msg, Runnable yes) {
        new AlertDialog.Builder(this).setMessage(msg).setPositiveButton("হ্যাঁ", (d, w) -> yes.run()).setNegativeButton("না", null).show();
    }
    double n(EditText e) { try { return Double.parseDouble(e.getText().toString().trim()); } catch (Exception x) { return 0; } }
    void watch(EditText e, Runnable r) {
        e.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            public void onTextChanged(CharSequence s, int a, int b, int c) { r.run(); }
            public void afterTextChanged(Editable s) { }
        });
    }

    // ---------- শুরু ----------
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Store.init(this);
        root = new FrameLayout(this);
        root.setBackgroundColor(0xFFF3F6FB);
        LinearLayout main = vbox(); root.addView(main, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout header = vbox(); header.setPadding(dp(16), dp(26), dp(16), dp(14));
        header.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF1258C9, 0xFF3188F4}));
        header.addView(tv("📒 হাজিরা ও কাজের হিসাব", 21, Color.WHITE, true));
        header.addView(tv("হাজিরা, বেতন ও ট্রিপের হিসাব • তথ্য ফোনে অটো-সেভ হবে", 12, 0xFFE8F0FF, false));
        main.addView(header);

        HorizontalScrollView hs = new HorizontalScrollView(this); hs.setBackgroundColor(Color.WHITE); hs.setHorizontalScrollBarEnabled(false);
        LinearLayout tabBar = new LinearLayout(this); tabBar.setPadding(dp(8), dp(8), dp(8), dp(8)); hs.addView(tabBar);
        main.addView(hs);

        ScrollView sv = new ScrollView(this); main.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));
        FrameLayout holder = new FrameLayout(this); holder.setPadding(dp(12), dp(4), dp(12), dp(90)); sv.addView(holder);
        for (int i = 0; i < 4; i++) {
            pages[i] = vbox(); holder.addView(pages[i], new FrameLayout.LayoutParams(-1, -2));
            final int idx = i;
            TextView t = tv(TABS[i], 14, 0xFF23456D, true); t.setPadding(dp(14), dp(10), dp(14), dp(10)); tabs[i] = t;
            t.setOnClickListener(v -> showPage(idx));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2); lp.rightMargin = dp(8); tabBar.addView(t, lp);
        }
        buildAttendance(); buildTrips(); buildReport(); buildBackup();
        setContentView(root);
        showPage(0);

        CalcBubble calc = new CalcBubble(this);
        root.addView(calc, new FrameLayout.LayoutParams(-2, -2));
        root.post(() -> { calc.setX(root.getWidth() - dp(36) - dp(12)); calc.setY(root.getHeight() - dp(36) - dp(90)); });
    }

    void showPage(int i) {
        for (int k = 0; k < 4; k++) {
            pages[k].setVisibility(k == i ? View.VISIBLE : View.GONE);
            tabs[k].setBackground(bg(k == i ? BRAND : 0xFFEDF3FC, 11));
            tabs[k].setTextColor(k == i ? Color.WHITE : 0xFF23456D);
        }
        refreshAll();
    }
    void refreshAll() { refreshAttendance(); refreshTrips(); refreshReport(); }

    // ---------- হাজিরা ও বেতন ----------
    void buildAttendance() {
        LinearLayout p = pages[0];
        LinearLayout sr = statRow(p);
        todayWage = stat(sr, "আজকের মোট বেতন"); presentCount = stat(sr, "আজ উপস্থিত"); advTotal = stat(sr, "মোট অগ্রিম");
        LinearLayout c = card(p, "দৈনিক হাজিরা ও বেতন");
        c.addView(note("নামে চাপ দিলে হাজিরা, দৈনিক মজুরি ও অগ্রিমের ঘর খুলবে। অনুপস্থিত হলে হাজিরা “অনুপস্থিত” নির্বাচন করুন। হিসাব আজকের তারিখে সেভ হবে।"));
        for (String w : Store.workers) {
            WRow r = new WRow();
            LinearLayout box = vbox(); box.setBackground(bg(Color.WHITE, 10)); box.setPadding(dp(10), dp(10), dp(10), dp(10));
            GradientDrawable stroke = bg(Color.WHITE, 10); stroke.setStroke(dp(1), 0xFFE3E9F2); box.setBackground(stroke);
            LinearLayout head = hbox(); head.addView(tv(w, 16, INK, true), new LinearLayout.LayoutParams(0, -2, 1));
            head.addView(tv("হিসাব লিখতে চাপ দিন", 11, MUTED, false)); box.addView(head);
            LinearLayout f = vbox(); f.setVisibility(View.GONE);
            r.p = new Spinner(this); r.p.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, PN));
            r.w = et("টাকা", true, null); r.a = et("টাকা", true, null);
            f.addView(labeled("হাজিরা", r.p)); f.addView(labeled("দৈনিক মজুরি (৳)", r.w)); f.addView(labeled("অগ্রিম (৳)", r.a));
            box.addView(f); head.setOnClickListener(v -> f.setVisibility(f.getVisibility() == View.GONE ? View.VISIBLE : View.GONE));
            c.addView(box, mp(8)); wrows.add(r);
        }
        c.addView(btn("হাজিরা সেভ করুন", BRAND, Color.WHITE, v -> saveAttendance()), mp(12));
        LinearLayout c2 = card(p, "এই তারিখের এন্ট্রি");
        entryDate = note(""); c2.addView(entryDate); attList = vbox(); c2.addView(attList);
    }

    void saveAttendance() {
        String date = Store.today(); List<JSONObject> rows = new ArrayList<>(); List<String> names = new ArrayList<>();
        for (int i = 0; i < wrows.size(); i++) {
            WRow r = wrows.get(i); double pr = PV[r.p.getSelectedItemPosition()];
            double wage = n(r.w) * pr, adv = n(r.a); String name = Store.workers.get(i);
            if (wage != 0 || adv != 0 || pr != 1) {
                rows.add(Store.obj("id", date + "_" + name, "date", date, "name", name, "type", "সাধারণ কাজ", "present", pr, "wage", wage, "advance", adv, "net", wage - adv));
                names.add(name);
            }
        }
        if (rows.isEmpty()) { toast("কোনো শ্রমিকের হিসাব লেখা হয়নি"); return; }
        List<JSONObject> keep = new ArrayList<>();
        for (JSONObject a : Store.att) if (!(Store.s(a, "date").equals(date) && names.contains(Store.s(a, "name")))) keep.add(a);
        keep.addAll(rows); Store.att = keep; Store.save(); refreshAll(); toast("হাজিরা সেভ হয়েছে");
    }

    void refreshAttendance() {
        String date = Store.today(); double wages = 0, adv = 0; int present = 0;
        entryDate.setText("(" + date + ")"); attList.removeAllViews();
        for (JSONObject a : Store.att) {
            if (!Store.s(a, "date").equals(date)) continue;
            double pr = Store.d(a, "present"); wages += Store.d(a, "wage"); adv += Store.d(a, "advance"); if (pr > 0) present++;
            String st = pr == 0 ? "অনুপস্থিত" : pr == .5 ? "অর্ধেক" : "উপস্থিত";
            LinearLayout row = hbox(); row.setPadding(0, dp(6), 0, dp(6));
            row.addView(tv(Store.s(a, "name") + " — " + st + "\nমজুরি " + Store.money(Store.d(a, "wage")) + " | অগ্রিম " + Store.money(Store.d(a, "advance"))
                    + " | পাওনা " + Store.money(Store.d(a, "net")), 13, INK, false), new LinearLayout.LayoutParams(0, -2, 1));
            final String id = Store.s(a, "id");
            row.addView(btn("রিমুভ", 0xFFFFF0F0, RED, v -> confirm("এই হাজিরাটি মুছে ফেলবেন?", () -> {
                List<JSONObject> k = new ArrayList<>(); for (JSONObject x : Store.att) if (!Store.s(x, "id").equals(id)) k.add(x);
                Store.att = k; Store.save(); refreshAll(); toast("এন্ট্রি মুছে ফেলা হয়েছে"); })));
            attList.addView(row);
        }
        if (attList.getChildCount() == 0) attList.addView(note("এই তারিখে এখনো কোনো এন্ট্রি নেই।"));
        todayWage.setText(Store.money(wages)); presentCount.setText(Store.fmt(present, 0) + " জন"); advTotal.setText(Store.money(adv));
    }

    // ---------- ট্রিপ ----------
    void buildTrips() {
        LinearLayout p = pages[1];
        LinearLayout sr = statRow(p);
        tripCount = stat(sr, "মোট ট্রিপ/গাড়ি"); tripCost = stat(sr, "মোট ট্রিপ খরচ"); laborCost = stat(sr, "টোটাল লেবার কস্ট");
        LinearLayout c = card(p, "🚚 সপ্তাহের ট্রিপের হিসাব");
        c.addView(note("বৃহস্পতিবার থেকে বুধবার পর্যন্ত প্রতিটি দিনের হিসাব আলাদা করে লিখুন।"));
        tripWeek = vbox(); c.addView(tripWeek);
        TextView[] o = new TextView[1]; band(c, "সব ট্রিপের মোট খরচ", o); tripGrand = o[0];
        c.addView(btn("সব ট্রিপ সেভ করুন", GREEN, Color.WHITE, v -> saveTrips()), mp(10));
        c.addView(btn("সব ট্রিপের বক্স খালি করুন", 0xFFEAF1FC, 0xFF174D9C, v -> confirm("এই সপ্তাহের সব ট্রিপের হিসাবের ঘর খালি করবেন? সেভ করা হিসাব মুছবে না।", () -> { buildTripWeek(); toast("ফর্মের ঘর খালি করা হয়েছে"); })), mp(8));
        LinearLayout c2 = card(p, "📅 সাত দিনের ট্রিপের সংক্ষিপ্ত হিসাব");
        LinearLayout r1 = statRow(c2); wkFare = stat(r1, "মোট ভাড়া"); wkLabor = stat(r1, "লেবার খরচ");
        LinearLayout r2 = statRow(c2); wkNet = stat(r2, "লেবার বাদে অবশিষ্ট"); wkComm = stat(r2, "ড্রাইভার কমিশন (১৫%)");
        c2.addView(cols(true, "দিন", "ভাড়া", "লেবার", "অবশিষ্ট", "ট্রিপ"), mp(8)); wkRows = vbox(); c2.addView(wkRows);
        LinearLayout c3 = card(p, "সেভ করা ট্রিপের বিস্তারিত"); tripDetail = vbox(); c3.addView(tripDetail);
        buildTripWeek();
    }

    void buildTripWeek() {
        tripWeek.removeAllViews(); entries.clear(); dayHeads.clear();
        for (String date : Store.weekDates()) {
            LinearLayout day = vbox(); day.setBackground(bg(0xFFF7FAFF, 12)); day.setPadding(dp(10), dp(10), dp(10), dp(10));
            LinearLayout head = hbox(); head.addView(tv(Store.dayName(date), 16, INK, true), new LinearLayout.LayoutParams(0, -2, 1));
            TextView tot = tv("৳০", 15, GREEN, true); head.addView(tot); day.addView(head); dayHeads.put(date, tot);
            List<JSONObject> saved = Store.tripsOn(date);
            for (JSONObject t : saved) {
                LinearLayout row = hbox(); row.setPadding(0, dp(6), 0, dp(6));
                row.addView(tv(Store.s(t, "material") + (Store.s(t, "destination").isEmpty() ? "" : " — " + Store.s(t, "destination")) + "\n" + Store.fmt(Store.d(t, "quantity"), 2)
                        + " ট্রিপ | ভাড়া " + Store.money(Store.gross(t)) + " | লেবার " + Store.money(Store.labor(t)) + " | অবশিষ্ট " + Store.money(Store.net(t)), 12, INK, false), new LinearLayout.LayoutParams(0, -2, 1));
                row.addView(btn("রিমুভ", 0xFFFFF0F0, RED, v -> removeTrip(Store.s(t, "id"), date))); day.addView(row);
            }
            LinearLayout list = vbox(); day.addView(list);
            if (saved.isEmpty()) addEntry(list, date, 0);
            LinearLayout acts = new LinearLayout(this);
            Button add = btn("＋ ট্রিপ অ্যাড করুন", 0xFFEAF1FC, 0xFF174D9C, v -> {
                int count = Store.tripsOn(date).size(); for (TEntry e : entries) if (e.date.equals(date)) count++;
                if (count >= 10) { toast("একদিনে সর্বোচ্চ ১০টি ট্রিপ রাখা যাবে"); return; } addEntry(list, date, count); calcTrips(); });
            Button save = btn("সেভ করুন", GREEN, Color.WHITE, v -> { List<JSONObject> rows = collect(date);
                if (rows.isEmpty()) { toast("সেভ করার মতো নতুন ট্রিপের তথ্য লিখুন"); return; }
                Store.trips.addAll(rows); Store.save(); refreshAll(); buildTripWeek(); toast("এই দিনের ট্রিপ সেভ হয়েছে"); });
            acts.addView(add, new LinearLayout.LayoutParams(0, -2, 1)); acts.addView(save, new LinearLayout.LayoutParams(0, -2, 1));
            day.addView(acts, mp(8)); tripWeek.addView(day, mp(10));
        }
        calcTrips();
    }

    void addEntry(LinearLayout list, String date, int index) {
        TEntry e = new TEntry(); e.date = date;
        LinearLayout box = vbox(); box.setPadding(0, dp(8), 0, dp(4));
        box.addView(tv("নতুন ট্রিপ " + (index + 1), 14, BRAND, true));
        e.m = new Spinner(this); e.m.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, Store.MATERIALS));
        e.dest = et("কোথায় গেছে", false, null); e.dest.setInputType(InputType.TYPE_CLASS_TEXT);
        e.q = et("0", true, "0"); e.r = et("0", true, "0"); e.l = et("0", true, "0");
        box.addView(labeled("ট্রিপের ধরন", e.m)); box.addView(labeled("গন্তব্য", e.dest)); box.addView(labeled("ট্রিপের সংখ্যা", e.q));
        box.addView(labeled("প্রতি ট্রিপের ভাড়া (৳)", e.r)); box.addView(labeled("লেবার খরচ (৳)", e.l));
        e.total = tv("লেবার বাদে ৳০", 14, GREEN, true); box.addView(e.total, mp(6));
        for (EditText x : new EditText[]{e.q, e.r, e.l}) watch(x, this::calcTrips);
        list.addView(box); entries.add(e);
    }

    List<JSONObject> collect(String date) {
        int existing = Store.tripsOn(date).size(), i = 0; String at = new Date().toString(); List<JSONObject> out = new ArrayList<>();
        for (TEntry e : entries) {
            if (!e.date.equals(date)) continue;
            double q = n(e.q), r = n(e.r), l = n(e.l); String dest = e.dest.getText().toString().trim(); i++;
            if (dest.isEmpty() && q == 0 && r == 0 && l == 0) continue;
            out.add(Store.obj("id", date + "_trip_" + (existing + i), "date", date, "number", existing + i, "material", Store.MATERIALS[e.m.getSelectedItemPosition()],
                    "destination", dest, "quantity", q, "rate", r, "labor", l, "total", q * r - l, "savedAt", at));
        }
        return out;
    }

    void saveTrips() {
        List<JSONObject> all = new ArrayList<>(); for (String d : Store.weekDates()) all.addAll(collect(d));
        if (all.isEmpty()) { toast("সেভ করার মতো নতুন ট্রিপের তথ্য নেই"); return; }
        Store.trips.addAll(all); Store.save(); refreshAll(); buildTripWeek(); toast("সপ্তাহের নতুন ট্রিপ সেভ হয়েছে");
    }

    void removeTrip(String id, String date) {
        confirm("এই ট্রিপটি মুছে ফেলবেন?", () -> {
            for (int i = 0; i < Store.trips.size(); i++) {
                JSONObject t = Store.trips.get(i);
                if (Store.s(t, "id").equals(id) && Store.s(t, "date").equals(date)) { Store.trips.remove(i); break; }
            }
            int k = 0; for (JSONObject x : Store.tripsOn(date)) { k++; try { x.put("number", k); x.put("id", date + "_trip_" + k); } catch (Exception e) { } }
            Store.save(); refreshAll(); buildTripWeek(); toast("ট্রিপটি মুছে ফেলা হয়েছে");
        });
    }

    void calcTrips() {
        double gross = 0, labor = 0, count = 0; Map<String, Double> dayTot = new HashMap<>();
        for (TEntry e : entries) {
            double q = n(e.q), r = n(e.r), l = n(e.l); gross += q * r; labor += l; count += q;
            e.total.setText("লেবার বাদে " + Store.money(q * r - l)); dayTot.put(e.date, (dayTot.containsKey(e.date) ? dayTot.get(e.date) : 0) + q * r - l);
        }
        tripGrand.setText(Store.money(gross - labor)); tripCost.setText(Store.money(gross - labor));
        tripCount.setText(Store.fmt(count, 2)); laborCost.setText(Store.money(labor));
        for (Map.Entry<String, TextView> h : dayHeads.entrySet()) {
            double t = dayTot.containsKey(h.getKey()) ? dayTot.get(h.getKey()) : 0;
            for (JSONObject x : Store.tripsOn(h.getKey())) t += Store.net(x);
            h.getValue().setText(Store.money(t));
        }
    }

    void refreshTrips() {
        wkRows.removeAllViews(); double fare = 0, labor = 0, net = 0;
        for (String date : Store.weekDates()) {
            double g = 0, l = 0, c = 0; for (JSONObject t : Store.tripsOn(date)) { g += Store.gross(t); l += Store.labor(t); c += Store.d(t, "quantity"); }
            fare += g; labor += l; net += g - l;
            wkRows.addView(cols(false, Store.dayName(date), Store.money(g), Store.money(l), Store.money(g - l), Store.fmt(c, 2)));
        }
        wkFare.setText(Store.money(fare)); wkLabor.setText(Store.money(labor)); wkNet.setText(Store.money(net)); wkComm.setText(Store.money(fare * 0.15));
        tripDetail.removeAllViews(); List<JSONObject> sorted = new ArrayList<>(Store.trips);
        Collections.sort(sorted, (a, b) -> { int c = Store.s(b, "date").compareTo(Store.s(a, "date")); return c != 0 ? c : Double.compare(Store.d(a, "number"), Store.d(b, "number")); });
        for (JSONObject t : sorted) {
            LinearLayout row = hbox(); row.setPadding(0, dp(6), 0, dp(6));
            row.addView(tv(Store.s(t, "date") + " (নং " + Store.fmt(Store.d(t, "number"), 0) + ")\n" + Store.s(t, "material") + " — " + Store.s(t, "destination") + " | " + Store.fmt(Store.d(t, "quantity"), 2)
                    + " ট্রিপ × " + Store.money(Store.d(t, "rate")) + " | লেবার " + Store.money(Store.labor(t)) + " | মোট " + Store.money(Store.net(t)), 12, INK, false), new LinearLayout.LayoutParams(0, -2, 1));
            final String id = Store.s(t, "id"), dt = Store.s(t, "date");
            row.addView(btn("রিমুভ", 0xFFFFF0F0, RED, v -> removeTrip(id, dt))); tripDetail.addView(row);
        }
        if (sorted.isEmpty()) tripDetail.addView(note("এখনো কোনো ট্রিপ সেভ করা হয়নি।"));
        calcTrips();
    }

    // ---------- রিপোর্ট ----------
    void buildReport() {
        LinearLayout p = pages[2];
        LinearLayout c = card(p, "📊 গত ৭ দিনের রিপোর্ট"); TextView[] o = new TextView[1]; band(c, "সব শ্রমিকের মোট পাওনা", o); repGrand = o[0];
        c.addView(cols(true, "শ্রমিক", "দিন", "বেতন", "অগ্রিম", "বাকি"), mp(10)); repRows = vbox(); c.addView(repRows);
        LinearLayout c2 = card(p, "🚚 সাত দিনের ট্রিপের হিসাব");
        LinearLayout r1 = statRow(c2); rtFare = stat(r1, "টোটাল ভাড়া"); rtLabor = stat(r1, "লেবার খরচ");
        LinearLayout r2 = statRow(c2); rtNet = stat(r2, "লেবার বাদে অবশিষ্ট"); rtComm = stat(r2, "ড্রাইভার কমিশন (১৫%)");
        c2.addView(cols(true, "দিন", "ভাড়া", "লেবার", "অবশিষ্ট"), mp(8)); repTripRows = vbox(); c2.addView(repTripRows);
    }

    void refreshReport() {
        String end = Store.today(), start = Store.shift(end, -6); double grand = 0; repRows.removeAllViews();
        for (String w : Store.workers) {
            double days = 0, wage = 0, adv = 0;
            for (JSONObject a : Store.att) {
                String d = Store.s(a, "date");
                if (Store.s(a, "name").equals(w) && d.compareTo(start) >= 0 && d.compareTo(end) <= 0) { days += Store.d(a, "present"); wage += Store.d(a, "wage"); adv += Store.d(a, "advance"); }
            }
            grand += wage - adv; repRows.addView(cols(false, w, Store.fmt(days, 2), Store.money(wage), Store.money(adv), Store.money(wage - adv)));
        }
        repGrand.setText(Store.money(grand)); repTripRows.removeAllViews(); double fare = 0, lab = 0, net = 0;
        for (int i = 0; i < 7; i++) {
            String ds = Store.shift(start, i); double g = 0, l = 0; for (JSONObject t : Store.tripsOn(ds)) { g += Store.gross(t); l += Store.labor(t); }
            fare += g; lab += l; net += g - l; repTripRows.addView(cols(false, Store.dayName(ds), Store.money(g), Store.money(l), Store.money(g - l)));
        }
        rtFare.setText(Store.money(fare)); rtLabor.setText(Store.money(lab)); rtNet.setText(Store.money(net)); rtComm.setText(Store.money(fare * 0.15));
    }

    // ---------- ব্যাকআপ ----------
    void buildBackup() {
        LinearLayout c = card(pages[3], "💾 ডেটা ব্যাকআপ ও রিস্টোর");
        c.addView(note("তথ্য এই ফোনের অ্যাপের ভেতরে সেভ থাকে। অ্যাপ আনইনস্টল করলে তথ্য হারাবে, তাই নিয়মিত ব্যাকআপ রাখুন।"));
        c.addView(btn("JSON ব্যাকআপ সেভ করুন", BRAND, Color.WHITE, v -> export("hisab-backup-" + Store.today() + ".json", "application/json", Store.toJson().toString(), 1)), mp(8));
        c.addView(btn("হাজিরার CSV সেভ করুন", 0xFFEAF1FC, 0xFF174D9C, v -> export("hajira-" + Store.today() + ".csv", "text/csv", csv(), 2)), mp(8));
        c.addView(btn("আগের JSON ব্যাকআপ ফিরিয়ে আনুন", GREEN, Color.WHITE, v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*"); startActivityForResult(i, 3); }), mp(8));
        c.addView(note("রিস্টোর করলে বর্তমান ডেটা বদলে যাবে; তার আগে বর্তমান ডেটার একটি নিরাপদ কপি অ্যাপের ভেতরে রাখা হবে।"));
        c.addView(btn("সব ডেটা মুছে ফেলুন", 0xFFFFF0F0, RED, v -> confirm("সব হাজিরা ও ট্রিপের ডেটা স্থায়ীভাবে মুছে ফেলবেন? মোছার আগে একটি নিরাপদ কপি রাখা হবে।", () -> {
            Store.safetyCopy(); Store.att = new ArrayList<>(); Store.trips = new ArrayList<>(); Store.save(); buildTripWeek(); refreshAll(); toast("সব ডেটা মুছে ফেলা হয়েছে"); })), mp(8));
    }

    String csv() {
        StringBuilder sb = new StringBuilder("\uFEFF\"তারিখ\",\"শ্রমিক\",\"কাজের ধরন\",\"হাজিরা\",\"বেতন\",\"অগ্রিম\",\"পাওনা\"\r\n");
        for (JSONObject a : Store.att) sb.append("\"").append(Store.s(a, "date")).append("\",\"").append(Store.s(a, "name").replace("\"", "\"\"")).append("\",\"")
                .append(Store.s(a, "type")).append("\",\"").append(Store.d(a, "present")).append("\",\"").append(Store.d(a, "wage")).append("\",\"")
                .append(Store.d(a, "advance")).append("\",\"").append(Store.d(a, "net")).append("\"\r\n");
        return sb.toString();
    }

    void export(String name, String mime, String content, int code) {
        pendingExport = content;
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType(mime); i.putExtra(Intent.EXTRA_TITLE, name);
        startActivityForResult(i, code);
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        Uri u = data.getData();
        try {
            if (req == 1 || req == 2) {
                try (OutputStream os = getContentResolver().openOutputStream(u)) { os.write(pendingExport.getBytes("UTF-8")); }
                toast("ফাইল সেভ হয়েছে");
            } else if (req == 3) {
                StringBuilder sb = new StringBuilder();
                try (BufferedReader br = new BufferedReader(new InputStreamReader(getContentResolver().openInputStream(u), "UTF-8"))) { String ln; while ((ln = br.readLine()) != null) sb.append(ln).append('\n'); }
                JSONObject d = new JSONObject(sb.toString());
                if (d.optJSONArray("attendance") == null && d.optJSONArray("trips") == null) throw new Exception();
                confirm("ব্যাকআপের ডেটা দিয়ে বর্তমান ডেটা প্রতিস্থাপন করবেন?", () -> {
                    Store.safetyCopy(); Store.fromJson(d); Store.save(); recreate(); });
            }
        } catch (Exception e) { toast(req == 3 ? "সঠিক JSON ব্যাকআপ ফাইল নির্বাচন করুন" : "ফাইল সেভ করা যায়নি"); }
    }
}
