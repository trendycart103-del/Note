package com.example.triperhisab;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.*;

/** ডেটা সংরক্ষণ ও হিসাবের নিয়ম (আগের HTML অ্যাপের মতোই, একই JSON ফরম্যাট) */
public class Store {
    static final String KEY = "attendance_trip_app_v1";
    static final String[] DEFAULT_WORKERS = {"প্রনব","লালু","শরীফ","জয়নাল","রুহুল আমিন","আমিন","তারিফুল","উজ্জ্বল","হাসান","নতুন শ্রমিক"};
    static final String[] DAYS = {"রবিবার","সোমবার","মঙ্গলবার","বুধবার","বৃহস্পতিবার","শুক্রবার","শনিবার"};
    static final String[] MATERIALS = {"বালু","ইট","রড","সিমেন্ট","পাথর","মাটি","খোয়া","অন্যান্য"};
    static SharedPreferences sp;
    static List<JSONObject> att = new ArrayList<>(), trips = new ArrayList<>();
    static List<String> workers = new ArrayList<>();
    static final SimpleDateFormat DF = new SimpleDateFormat("yyyy-MM-dd", Locale.US);

    static JSONObject obj(Object... kv) {
        JSONObject o = new JSONObject();
        try { for (int i = 0; i < kv.length; i += 2) o.put((String) kv[i], kv[i + 1]); } catch (Exception e) { }
        return o;
    }
    static double d(JSONObject o, String k) { return o.optDouble(k, 0); }
    static String s(JSONObject o, String k) { return o.optString(k, ""); }

    static String rn(String n) {
        n = n == null ? "" : n.trim();
        if (n.equals("তারিকুল") || n.equals("তারেক ফুল")) return "তারিফুল";
        if (n.equals("শোরিফ")) return "শরীফ";
        return n;
    }

    static void init(Context c) {
        sp = c.getSharedPreferences("hisab", Context.MODE_PRIVATE);
        String raw = sp.getString(KEY, null);
        try { if (raw != null) fromJson(new JSONObject(raw)); else fromJson(new JSONObject()); } catch (Exception e) { fromJson(new JSONObject()); }
    }

    static void fromJson(JSONObject j) {
        att = new ArrayList<>(); trips = new ArrayList<>(); workers = new ArrayList<>();
        JSONArray a = j.optJSONArray("attendance"), t = j.optJSONArray("trips"), w = j.optJSONArray("workers");
        if (a != null) for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i); if (o == null) continue;
            String name = rn(s(o, "name")), date = s(o, "date");
            double wage = d(o, "wage"), adv = d(o, "advance");
            att.add(obj("id", date + "_" + name, "date", date, "name", name, "type", o.optString("type", "সাধারণ কাজ"),
                    "present", o.optDouble("present", 1), "wage", wage, "advance", adv, "net", o.has("net") ? d(o, "net") : wage - adv));
        }
        if (t != null) for (int i = 0; i < t.length(); i++) { JSONObject o = t.optJSONObject(i); if (o != null) trips.add(o); }
        for (String n : DEFAULT_WORKERS) addWorker(n);
        if (w != null) for (int i = 0; i < w.length(); i++) addWorker(w.optString(i));
        for (JSONObject o : att) addWorker(s(o, "name"));
    }
    static void addWorker(String n) { n = rn(n); if (!n.isEmpty() && !workers.contains(n)) workers.add(n); }

    static JSONObject toJson() {
        JSONObject o = new JSONObject();
        try {
            o.put("attendance", new JSONArray(att)); o.put("trips", new JSONArray(trips)); o.put("workers", new JSONArray(workers));
        } catch (Exception e) { }
        return o;
    }
    static void save() { sp.edit().putString(KEY, toJson().toString()).apply(); }

    static void safetyCopy() {
        sp.edit().putString(KEY + "_safe_" + System.currentTimeMillis(), toJson().toString()).apply();
        List<String> keys = new ArrayList<>();
        for (String k : sp.getAll().keySet()) if (k.startsWith(KEY + "_safe_")) keys.add(k);
        Collections.sort(keys);
        SharedPreferences.Editor ed = sp.edit();
        for (int i = 0; i < keys.size() - 5; i++) ed.remove(keys.get(i));
        ed.apply();
    }

    static String today() { return DF.format(new Date()); }
    static String shift(String date, int days) {
        try { Calendar c = Calendar.getInstance(); c.setTime(DF.parse(date)); c.add(Calendar.DATE, days); return DF.format(c.getTime()); }
        catch (Exception e) { return date; }
    }
    /** বৃহস্পতিবার থেকে বুধবার পর্যন্ত চলতি সপ্তাহ */
    static List<String> weekDates() {
        Calendar c = Calendar.getInstance();
        int js = c.get(Calendar.DAY_OF_WEEK) - 1;
        int back = (js - 4 + 7) % 7;
        String start = shift(today(), -back);
        List<String> l = new ArrayList<>();
        for (int i = 0; i < 7; i++) l.add(shift(start, i));
        return l;
    }
    static String dayName(String date) {
        try { Calendar c = Calendar.getInstance(); c.setTime(DF.parse(date)); return DAYS[c.get(Calendar.DAY_OF_WEEK) - 1]; }
        catch (Exception e) { return date; }
    }

    static String fmt(double n, int maxFrac) {
        NumberFormat f = NumberFormat.getInstance(new Locale("bn", "BD"));
        f.setMaximumFractionDigits(maxFrac);
        return f.format(n);
    }
    static String money(double n) { return "৳" + fmt(n, 2); }

    static double gross(JSONObject t) { return d(t, "quantity") * d(t, "rate"); }
    static double labor(JSONObject t) { return d(t, "labor"); }
    static double net(JSONObject t) { return gross(t) - labor(t); }
    static List<JSONObject> tripsOn(String date) {
        List<JSONObject> l = new ArrayList<>();
        for (JSONObject t : trips) if (s(t, "date").equals(date)) l.add(t);
        Collections.sort(l, (a, b) -> Double.compare(d(a, "number"), d(b, "number")));
        return l;
    }
}
